﻿Public Interface factoryCreator
    Function CrearListaRestaurantes() As List(Of platillos)
End Interface
