﻿Public Interface IAlmuerzo
    Sub crearAlmuerzo()
    Sub aumentarPrecio(ByVal precio As Double)
    Function getPrecio() As Double
End Interface
