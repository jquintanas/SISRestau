﻿Public Interface IFormaDePago2
    Sub pagar(ByVal monto As Double)
    Sub generarOrden()
End Interface

Public Class IFormaDePago

End Class
