﻿Module utilRestaurante
    Public Function crearRestaurantes(ByVal ruta As String) As List(Of restaurante)
        Dim lrest As New List(Of restaurante)
        Dim dicT As New Dictionary(Of String, Collection)
        dicT = lecturaDeArchivo.leerArchivo(ruta)
        Dim i As Integer = 0
        For Each col As Collection In dicT.Values
            lrest.Add(New restaurante(col.Item(1).Item(1), col.Item(1).Item(2), Convert.ToInt64(col.Item(1).Item(3)), col.Item(1).Item(4), New List(Of platillos)))
        Next
        Return lrest

    End Function
End Module
