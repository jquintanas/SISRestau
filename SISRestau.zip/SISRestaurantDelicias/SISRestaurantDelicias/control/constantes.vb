﻿Module constantes
    Public Const estudiante = "usuario"
    Public Const asistenteR = "adminRestaurante"
    Public Const administradorSis = "administrador"
    Public Const malicia = "Nueva Malisia"
    Public Const celex = "Comerdor Celex"


End Module
